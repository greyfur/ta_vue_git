<template>
  <div class="approvalDone">
    <pay-com goDetailName='approvalDone' processStatusCom='审批完成' urlName='approvalDone'></pay-com>
  </div>
</template>
<script>
import payCom from '@/components/payCom.vue'
export default {
  components:{
    payCom
  },
  data() {
    return {
      
    }
  }
}
</script>

