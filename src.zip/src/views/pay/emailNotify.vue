<template>
  <div class="emailNotify">
    <pay-com goDetailName='' processStatusCom='待邮件通知' urlName='emailNotify'></pay-com>
  </div>
</template>
<script>
import payCom from '@/components/payCom.vue'
export default {
  components:{
    payCom
  },
  data() {
    return {
      
    }
  }
}
</script>

