<template>
  <div class="collectiongEnd">
    <receipt-com goDetailName='collectiongEnd' processStatusCom='已完结' urlName='collectiongEnd'></receipt-com>
  </div>
</template>
<script>
import receiptCom from '@/components/receiptCom.vue'
export default {
  components:{
    receiptCom
  },
  data() {
    return {
      
    }
  }
}
</script>

