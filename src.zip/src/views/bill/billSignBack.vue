<template>
  <div class="billSignBack">
    <bill-com processStatusCom='待签回' urlName='billSignBack'></bill-com>
  </div>
</template>
<script>
import billCom from '@/components/billCom.vue'
export default {
  components:{
    billCom
  },
  data() {
    return {
      
    }
  }
}
</script>

