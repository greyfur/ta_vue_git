<template>
  <div class="sortOperation">
    <bill-com processStatusCom='已创建' urlName='sortOperation'></bill-com>
  </div>
</template>
<script>
import billCom from '@/components/billCom.vue'
export default {
  components:{
    billCom
  },
  data() {
    return {
      
    }
  }
}
</script>

