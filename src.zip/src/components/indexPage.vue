<template>
  <div class="indexPage">
    
  </div>
</template>

<script>
  export default {
    name:'indexPage',
    data() {
      return {

      };
    },
    created(){
      // if(this.$store.state.deFineRout.length < 4){
      //   setTimeout(()=>{ this.$router.go(0) },500)
      // }
    },
    mounted(){
      
    },
    methods: {
     
    }
  }
</script>
<style>

</style>
